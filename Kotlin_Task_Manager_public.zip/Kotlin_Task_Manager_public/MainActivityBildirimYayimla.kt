package com.x.x

//************************* Bildirim oluşturma sayfası ********************************************

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.acd.taskanager.Bildirim
import com.google.firebase.firestore.FirebaseFirestore

class MainActivityBildirimYayimla : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.bildirim_yayimla)

        val butonKaydet: Button = findViewById(R.id.butonKaydet)
        val butonGeridon: Button = findViewById(R.id.butonGeridon)
        val editBildirimBasligi: EditText = findViewById(R.id.editBildirimBaslik)
        val editBildirimTarihi: EditText = findViewById(R.id.editBildirimTarih)
        val spinnerGorevDurumu: Spinner = findViewById(R.id.spinnerGorevDurum)
        val editBildirimAciklama: EditText = findViewById(R.id.editBildirimAcikla)

        editBildirimAciklama.setPadding(15,15,15,15)
        editBildirimBasligi.setPadding(10,0,0,0)
        editBildirimTarihi.setPadding(10,0,0,0)

        butonKaydet.setOnClickListener {
            // Formdaki bilgileri al
            val bildirimBasligi = editBildirimBasligi.text.toString()
            val bildirimTarihi = editBildirimTarihi.text.toString()
            val gorevDurumuStr: String = spinnerGorevDurumu.selectedItem.toString()
            val bildirimAciklamasi = editBildirimAciklama.text.toString()


            // Bilgileri kontrol et
            if (bildirimBasligi.isNotEmpty() &&
                bildirimTarihi.isNotEmpty() && gorevDurumuStr.isNotEmpty()
            ) {
                // Bilgileri Firestore'a ekle
                val bildirim = Bildirim(bildirimBasligi, bildirimTarihi, gorevDurumuStr, bildirimAciklamasi)
                ekleFirestore(bildirim)
            } else {
                // Hata durumunda kullanıcıya bilgi ver
                Toast.makeText(
                    this,
                    "Hatalı giriş! Bilgilerinizi kontrol ediniz",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        butonGeridon.setOnClickListener {
            val intent = Intent(this, MainActivityAuth::class.java)
            startActivity(intent)
            finish()
        }
    }

    //************** Bildirimleri Firestore veritabanına ekleme fonksiyonu *************************
    private fun ekleFirestore(bildirim: Bildirim) {
        db.collection("bildirimler")
            .add(bildirim)
            .addOnSuccessListener {
                // Ekleme başarılı oldu
                Toast.makeText(this, "Başarıyla kaydedildi!", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
                // Ekleme başarısız oldu
                Toast.makeText(this, "Hata: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}
