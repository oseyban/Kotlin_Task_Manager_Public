package com.acd.taskmanager

//****************************** Görevleri Listeleme Sayfası **************************************

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import com.google.firebase.firestore.FirebaseFirestore


class MainActivityGorevListele : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.gorev_listele)

        val butonYeniGorevTanimla: Button = findViewById(R.id.butonYeniGorevTanimla)
        val butonGeridon: Button = findViewById(R.id.butonGeridon)
        val listView: ListView = findViewById(R.id.listViewGorev)

        val gorevListesi: ArrayList<String> = ArrayList()


        // Firestore koleksiyonundan veri çekme
        db.collection("gorevler")
            .get()
            .addOnSuccessListener { documents ->
                for (document in documents) {
                    val gorevAdi = document.getString("gorevAdi")
                    val gorevDurumu = document.getString("gorevDurumu")
                    val gorevOncelik = document.getString("gorevOncelik")
                    val tarih = document.getString("tarih")
                    val aciklama = document.getString("aciklama")

                    // Görev bilgilerini listeye ekle
                    val gorevBilgisi =
                        "Görev Adı: $gorevAdi\nDurumu: $gorevDurumu\nÖncelik: $gorevOncelik\nTarih: $tarih\nAçıklama: $aciklama"
                    gorevListesi.add(gorevBilgisi)
                }

                // ListView'e adaptörü ayarla
                val adapter = GorevListAdapter(this, R.layout.gorev_liste_duzeni, R.id.textViewGorevAdi, gorevListesi)
                listView.adapter = adapter
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Listeleme Hatası: " + exception.message, Toast.LENGTH_SHORT).show()
            }

        butonYeniGorevTanimla.setOnClickListener {
            val intent = Intent(this, MainActivityGorevTanimla::class.java)
            startActivity(intent)
            finish()
        }

        butonGeridon.setOnClickListener {
            val intent = Intent(this, MainActivityAuth::class.java)
            startActivity(intent)
            finish()
        }
    }
}

//
class GorevListAdapter(
    context: Context,
    private val listexml: Int,
    private val textViewAdId: Int,
    private val gorevListesi: ArrayList<String>
) : ArrayAdapter<String>(context, listexml, textViewAdId, gorevListesi) {

    @SuppressLint("SetTextI18n", "ViewHolder")
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val inflater = LayoutInflater.from(context)
        val rowView = inflater.inflate(listexml, parent, false)

        val db=FirebaseFirestore.getInstance()
        val textViewGorevAdi: TextView = rowView.findViewById(textViewAdId)
        val cardView: CardView = rowView.findViewById(R.id.cardView)
        val btnSil: Button = rowView.findViewById(R.id.btnSil)

        textViewGorevAdi.text = gorevListesi[position]

        cardView.radius = 8f

        btnSil.setOnClickListener {
            deleteGorev(context, gorevListesi[position])
            deleteGorevKisi(context, gorevListesi[position])
            updateData(position)
        }

        val gorevAdi = parseGorevAdi(gorevListesi[position])

        // Alt koleksiyondan atananlar listesini çek
        db.collection("gorevler")
            .document(gorevAdi)
            .collection("atananlar")
            .get()
            .addOnSuccessListener { atananlarDocuments ->
                val atananlarListesi = ArrayList<String>()

                // Belge var mı kontrol et
                if (!atananlarDocuments.isEmpty) {
                    for (atananlarDocument in atananlarDocuments) {
                        // Atananlar alt koleksiyon belgesini al
                        val atanilanBelgeAdi = atananlarDocument.id
                        atananlarListesi.add(atanilanBelgeAdi)
                    }

                    // Atananlar listesini textView'e ekle
                    val textViewGorevDetay: TextView = rowView.findViewById(R.id.textViewGorevDetay)
                    textViewGorevDetay.text = "Atananlar: \n${atananlarListesi.joinToString("\n")}"

                } else {
                    // Atananlar listesi boşsa, burada ne yapılacağını belirtin (örneğin, bir mesaj gösterin)
                    val textViewGorevDetay: TextView = rowView.findViewById(R.id.textViewGorevDetay)
                    textViewGorevDetay.text = "Atananlar: (Atanan Yok)"
                }
            }
            .addOnFailureListener { exception ->
                // Hata durumunda buraya düşer
                Toast.makeText(context, "Atananlar Listeleme Hatası: " + exception.message, Toast.LENGTH_SHORT).show()
            }

        return rowView
    }

    //*************** verileri güncelle fonksiyonu ************************************************
    private fun updateData(position: Int) {
        gorevListesi.removeAt(position)
        notifyDataSetChanged()
    }
}

// ********************* görev Silme fonksiyonu ****************************************************
private fun deleteGorev(context: Context, gorev: String) {
    val db = FirebaseFirestore.getInstance()

    // Görev Adı'nı çıkarmak için stringi parse et
    val gorevAdi = parseGorevAdi(gorev)

    // Görevleri sorgula
    db.collection("gorevler")
        .whereEqualTo("gorevAdi", gorevAdi)
        .get()
        .addOnSuccessListener { documents ->
            for (document in documents) {
                // Alt koleksiyonları sil
                db.collection("gorevler")
                    .document(document.id)
                    .collection("atananlar")
                    .get()
                    .addOnSuccessListener { atananlarDocuments ->
                        for (atananlarDocument in atananlarDocuments) {
                            db.collection("gorevler")
                                .document(document.id)
                                .collection("atananlar")
                                .document(atananlarDocument.id)
                                .delete()
                                .addOnSuccessListener {
                                    // Alt koleksiyon belgesi silindiğinde yapılacak işlemler
                                }
                        }
                    }

                // Üst düzey belgeyi sil
                db.collection("gorevler")
                    .document(document.id)
                    .delete()
                    .addOnSuccessListener {
                        Toast.makeText(context, "Görev başarıyla silindi", Toast.LENGTH_SHORT).show()

                        // Görev Adı belgesini de sil
                        db.collection("gorevler")
                            .document(document.id)
                            .delete()
                            .addOnSuccessListener {
                                Toast.makeText(context, "Görev Adı belgesi başarıyla silindi", Toast.LENGTH_SHORT).show()
                            }
                            .addOnFailureListener { exception ->
                                Toast.makeText(context, "Görev Adı belgesi silme hatası: ${exception.message}", Toast.LENGTH_SHORT).show()
                            }
                    }
                    .addOnFailureListener { exception ->
                        Toast.makeText(context, "Silme hatası: ${exception.message}", Toast.LENGTH_SHORT).show()
                    }
            }
        }
        .addOnFailureListener { exception ->
            Toast.makeText(context, "Sorgu hatası: ${exception.message}", Toast.LENGTH_SHORT).show()
        }
}

//************************** kişilerdeki atanan görevleri silme fonksiyonu ***********************
private fun deleteGorevKisi(context: Context, gorev: String) {
    val db = FirebaseFirestore.getInstance()

    // Görev bilgileri içinden görev adını ayır
    val gorevAdi = parseGorevAdi(gorev)

    db.collection("kisiler")
        .get()
        .addOnSuccessListener { kisilerSnapshot ->
            for (kisiDocument in kisilerSnapshot) {
                val kisiId = kisiDocument.id

                db.collection("kisiler")
                    .document(kisiId)
                    .collection("atananGorevler")
                    .whereEqualTo("gorevAdi", gorevAdi)
                    .get()
                    .addOnSuccessListener { gorevlerSnapshot ->
                        for (gorevDocument in gorevlerSnapshot) {
                            db.collection("kisiler")
                                .document(kisiId)
                                .collection("atananGorevler")
                                .document(gorevDocument.id)
                                .delete()
                                .addOnSuccessListener {
                                    Toast.makeText(context, "Görev başarıyla silindi", Toast.LENGTH_SHORT).show()
                                }
                                .addOnFailureListener { exception ->
                                    Toast.makeText(context, "Silme hatası: ${exception.message}", Toast.LENGTH_SHORT).show()
                                }
                        }
                    }
                    .addOnFailureListener { exception ->
                        Toast.makeText(context, "Sorgu hatası: ${exception.message}", Toast.LENGTH_SHORT).show()
                    }
            }
        }
        .addOnFailureListener { exception ->
            Toast.makeText(context, "Kişileri getirme hatası: ${exception.message}", Toast.LENGTH_SHORT).show()
        }
}

//***************** Görev Adı'nı ayırmak için kullanılan yardımcı fonksiyon************************
private fun parseGorevAdi(gorev: String): String {
    val gorevAdiIndex = gorev.indexOf("Görev Adı: ") + "Görev Adı: ".length
    val durumuIndex = gorev.indexOf("Durumu: ")
    return if (gorevAdiIndex >= 0 && durumuIndex >= 0) {
        gorev.substring(gorevAdiIndex, durumuIndex).trim()
    } else {
        ""
    }
}


