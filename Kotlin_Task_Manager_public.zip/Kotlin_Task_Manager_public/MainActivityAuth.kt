package com.x.x

//************************************* yönetim sayfası *******************************************

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class MainActivityAuth : AppCompatActivity() {

        private lateinit var butonCikis: Button
        private lateinit var butonGorevTanimla: Button
        private lateinit var butonGorevGuncelle: Button
        private lateinit var butonBildirimYayimla: Button
        private lateinit var butonGorevAta: Button
        private lateinit var butonGorevListele: Button
        private lateinit var butonBildirimListele: Button

        @SuppressLint("MissingInflatedId")
        override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_auth)

        butonCikis = findViewById(R.id.butonCikis)
        butonGorevTanimla = findViewById(R.id.butonGorevTanimla)
        butonGorevGuncelle = findViewById(R.id.butonGorevGuncelle)
        butonBildirimYayimla = findViewById(R.id.butonBildirimYayimla)
        butonGorevAta = findViewById(R.id.butonGorevAtama)
        butonGorevListele = findViewById(R.id.butonGorevListele)
        butonBildirimListele = findViewById(R.id.butonBildirimListele)


        butonGorevListele.setOnClickListener {
            val intent = Intent(this, MainActivityGorevListele::class.java)
            startActivity(intent)
        }
        butonBildirimListele.setOnClickListener {
            val intent = Intent(this, MainActivityBildirimListele::class.java)
            startActivity(intent)
        }
        butonGorevTanimla.setOnClickListener {
            val intent = Intent(this, MainActivityGorevTanimla::class.java)
            startActivity(intent)
        }
        butonBildirimYayimla.setOnClickListener {
            val intent = Intent(this, MainActivityBildirimYayimla::class.java)
            startActivity(intent)
        }
        butonGorevAta.setOnClickListener {
            val intent = Intent(this, MainActivityGorevAta::class.java)
            startActivity(intent)
        }
        butonGorevGuncelle.setOnClickListener {
            val intent = Intent(this, MainActivityGorevGuncelle::class.java)
            startActivity(intent)
        }

        butonCikis.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}
