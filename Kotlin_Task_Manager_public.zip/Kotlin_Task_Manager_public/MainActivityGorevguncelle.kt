package com.x.x.x

//*************** Görevlerde bir değişiklik yapılacağında görevin güncelleneceği sayfa**************

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivityGorevGuncelle : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()
    private lateinit var auth: FirebaseAuth

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.gorev_guncelle)

        val butonGuncelle: Button = findViewById(R.id.butonGuncelle)
        val butonGeridon: Button = findViewById(R.id.butonGeridon)
        val spinnerGorevAdi: Spinner = findViewById(R.id.spinnerGorevAdi)
        val oncelik: Spinner = findViewById(R.id.spinnerOncelik)
        val editGorevTarihi: EditText = findViewById(R.id.editGorevTarihi)
        val gorevdurumu: Spinner = findViewById(R.id.spinnerGorevDurumu)
        val gorevaciklama: EditText = findViewById(R.id.editGorevAciklama)
        editGorevTarihi.setPadding(10,0,0,0)

        auth = FirebaseAuth.getInstance()

        // Firestore'dan görev adlarını çek ve spinner'ı doldur
        val gorevAdlari = mutableListOf<String>("Görev Seçiniz")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, gorevAdlari)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerGorevAdi.adapter = adapter

        db.collection("gorevler")
            .get()
            .addOnSuccessListener { belgeler ->
                for (belge in belgeler) {
                    val gorevAdi = belge.getString("gorevAdi")
                    gorevAdi?.let {
                        gorevAdlari.add(it)
                    }
                }
                adapter.notifyDataSetChanged()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Hata: ${e.message}", Toast.LENGTH_SHORT).show()
            }

        // *************SpinnerGorevAdi(açılır menü) oluşturma işlemi  **************************
        // onItemSelectedListener fonksiyonu ile açılır menüdeki seçili eleman kontrol ediliyor
        spinnerGorevAdi.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parentView: AdapterView<*>, selectedItemView: View, position: Int, id: Long) {
                // Seçilen görev adını al
                val secilenGorevAdi = spinnerGorevAdi.selectedItem.toString()

                // Firestore'dan seçilen göreve ait diğer bilgileri çek ve alanları doldur
                db.collection("gorevler")
                    .whereEqualTo("gorevAdi", secilenGorevAdi)
                    .get()
                    .addOnSuccessListener { belgeler ->
                        if (!belgeler.isEmpty) {
                            val belge = belgeler.first()
                            val oncelikStr = belge.getString("oncelik")
                            val tarih = belge.getString("tarih")
                            val gorevDurumuStr = belge.getString("durumu")
                            val gorevAciklamasi = belge.getString("aciklama")

                            // Diğer alanları seçilen görevden gelen değerlerle doldur
                            oncelik.setSelection(getIndex(oncelik, oncelikStr))
                            editGorevTarihi.setText(tarih)
                            gorevdurumu.setSelection(getIndex(gorevdurumu, gorevDurumuStr))
                            gorevaciklama.setText(gorevAciklamasi)
                        }
                    }
                    .addOnFailureListener { e ->
                        Toast.makeText(this@MainActivityGorevGuncelle, "Hata: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
            }

            override fun onNothingSelected(parentView: AdapterView<*>) {
                // Hiçbir şey seçilmediğinde bir şey yapma
            }
        })

        // Formdaki bilgileri al ve guncelleFirebase fonksiyonuna gönder
        butonGuncelle.setOnClickListener {
            val gorevAdi = spinnerGorevAdi.selectedItem.toString()
            val oncelikStr: String = oncelik.selectedItem.toString()
            val gorevDurumuStr: String = gorevdurumu.selectedItem.toString()
            val gorevaciklamasi = gorevaciklama.text.toString()
            val tarih = editGorevTarihi.text.toString()


            // Bilgileri kontrol et
            if (gorevAdi.isNotEmpty() && oncelikStr.isNotEmpty() && gorevDurumuStr.isNotEmpty()) {
                // Bilgileri Firestore'a güncelle
                guncelleFirestore(gorevAdi, oncelikStr, tarih, gorevDurumuStr, gorevaciklamasi)
            } else {
                // Hata durumunda kullanıcıya bilgi ver
                Toast.makeText(
                    this,
                    "Hatalı giriş! Bilgilerinizi kontrol ediniz",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        butonGeridon.setOnClickListener {
            val intent = Intent(this, MainActivityAuth::class.java)
            startActivity(intent)
            finish()
        }
    }

    // ******************** açılır listedeki seçili elemanın index numarasını döndürür ************
    private fun getIndex(spinner: Spinner, value: String?): Int {
        for (i in 0 until spinner.count) {
            if (spinner.getItemAtPosition(i).toString() == value) {
                return i
            }
        }
        return 0
    }

    //*************** veritabanındaki bilgileri güncelleme fonksiyonu*******************************
    private fun guncelleFirestore(
        gorevAdi: String,
        oncelikStr: String,
        tarih: String,
        gorevDurumuStr: String,
        gorevaciklamasi: String
    ) {
        // Firestore veritabanında güncelleme işlemi
        val guncellenecekBilgiler = mapOf(
            "oncelik" to oncelikStr,
            "tarih" to tarih,
            "durumu" to gorevDurumuStr,
            "aciklama" to gorevaciklamasi
        )

        db.collection("gorevler")
            .whereEqualTo("gorevAdi", gorevAdi)
            .get()
            .addOnSuccessListener { belgeler ->
                if (!belgeler.isEmpty) {
                    val belge = belgeler.first()
                    // Güncellenen değerleri Firestore'da güncelle
                    db.collection("gorevler")
                        .document(belge.id)
                        .update(guncellenecekBilgiler)
                        .addOnSuccessListener {
                            Toast.makeText(this, "Görev başarıyla güncellendi!", Toast.LENGTH_SHORT).show()
                        }
                        .addOnFailureListener { e ->
                            Toast.makeText(this, "Hata: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Hata: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}
