package com.x.x

//************************ Bildirim Listeleme Sayfası *********************************************

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query


@Suppress("NAME_SHADOWING")
class MainActivityBildirimListele : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.bildirim_listele)

        val butonGeridon: Button = findViewById(R.id.butonGeridon)
        val listView: ListView = findViewById(R.id.listViewBildirim)

        val duyuruListesi: ArrayList<String> = ArrayList()

        val adapter = GorevListAdapter2(this, R.layout.bildirim_liste_duzeni, R.id.textViewBildirimAdi, duyuruListesi)
        listView.adapter = adapter

        butonGeridon.setOnClickListener {
            val intent = Intent(this, MainActivityAuth::class.java)
            startActivity(intent)
            finish()
        }

        // Firestore koleksiyonundan veri çekme
        db.collection("bildirimler")
            .orderBy("tarih", Query.Direction.DESCENDING)
            .get()
            .addOnSuccessListener { documents ->
                for (document in documents) {
                    val baslik = document.getString("baslik")
                    val gorevDurumu = document.getString("gorevDurumu")
                    val tarih = document.getString("tarih")
                    val aciklama = document.getString("aciklama")

                    // Görev bilgilerini listeye ekle
                    val gorevBilgisi =
                        "Duyuru Adı: $baslik\nGörev Durumu: $gorevDurumu\nDuyuru Tarihi: $tarih\nAçıklama: $aciklama"
                    duyuruListesi.add(gorevBilgisi)
                }

                // verileri ListView'de görmek için adaptör ayarla
                val adapter = GorevListAdapter2(this, R.layout.bildirim_liste_duzeni, R.id.textViewBildirimAdi, duyuruListesi)
                listView.adapter = adapter
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Listeleme Hatası: "+exception.message, Toast.LENGTH_SHORT).show()
            }

        butonGeridon.setOnClickListener {
            val intent = Intent(this, MainActivityAuth::class.java)
            startActivity(intent)
            finish()
        }
    }
}


//*********************** listview de verileri listelemek için kullanılan fonksiyon ****************
class GorevListAdapter2(context: Context,
                        private val listexml: Int,
                        private val textViewAdId: Int,
                        private val duyuruListesi: ArrayList<String>) :
    ArrayAdapter<String>(context, listexml, textViewAdId, duyuruListesi) {

    @SuppressLint("ViewHolder")
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val inflater = LayoutInflater.from(context)
        val rowView = inflater.inflate(listexml, parent, false)

        val textViewBildirimAdi: TextView = rowView.findViewById(textViewAdId)
        val cardView: CardView = rowView.findViewById(R.id.cardView)
        val btnSil: Button = rowView.findViewById(R.id.btnSil)


        textViewBildirimAdi.text = duyuruListesi[position]
        cardView.radius = 8f

        // Sil düğmesine tıklanınca silme işlemi gerçekleştir
        btnSil.setOnClickListener {
            deleteDuyuru(context, duyuruListesi[position])
            updateData(position)
        }


        return rowView
    }

    // Duyuru silindiğinde veriyi güncelle
    private fun updateData(position: Int) {
        duyuruListesi.removeAt(position)
        notifyDataSetChanged()
    }
}


//************** Duyuru silme fonksiyonu ****************************************************
private fun deleteDuyuru(context: Context, duyuru: String) {
    val db = FirebaseFirestore.getInstance()

    // Duyuru Adı'nı çıkarmak için stringi parse et
    val duyuruAdi = parseDuyuruAdi(duyuru)

    db.collection("bildirimler")
        .whereEqualTo("baslik", duyuruAdi)
        .get()
        .addOnSuccessListener { documents ->
            for (document in documents) {
                db.collection("bildirimler")
                    .document(document.id)
                    .delete()
                    .addOnSuccessListener {
                        Toast.makeText(context, "Duyuru başarıyla silindi", Toast.LENGTH_SHORT).show()
                    }
                    .addOnFailureListener { exception ->
                        Toast.makeText(context, "Silme hatası: ${exception.message}", Toast.LENGTH_SHORT).show()
                    }
            }
        }
        .addOnFailureListener { exception ->
            Toast.makeText(context, "Sorgu hatası: ${exception.message}", Toast.LENGTH_SHORT).show()
        }
}

// Duyuru Adı'nı duyuru içindeki bilgilerden ayırmak için yardımcı fonksiyon
private fun parseDuyuruAdi(duyuru: String): String {
    val duyuruAdiIndex = duyuru.indexOf("Duyuru Adı: ") + "Duyuru Adı: ".length
    val gorevDurumuIndex = duyuru.indexOf("Görev Durumu: ")
    return if (duyuruAdiIndex >= 0 && gorevDurumuIndex >= 0) {
        duyuru.substring(duyuruAdiIndex, gorevDurumuIndex).trim()
    } else {
        ""
    }
}
