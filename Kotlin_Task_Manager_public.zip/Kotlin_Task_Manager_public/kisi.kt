package com.x.x

data class Kisi(
    val adSoyad: String,
    val email: String,
    val telefon: String,
    val pozisyon: String,
    val token:String
)
