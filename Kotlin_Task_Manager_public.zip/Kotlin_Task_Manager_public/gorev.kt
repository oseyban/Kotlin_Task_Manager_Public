package com.x.x
data class Gorev(
    val gorevAdi: String,
    val oncelik: String,
    val tarih: String,
    val durumu: String,
    val aciklama: String
)

data class Gorev01(
    val gorevAdi: String? = null,
    val gorevAciklama: String? = null,
    val durumu: String? = null,
    val oncelik: String? = null,
    val tarih: String? = null,
    )
