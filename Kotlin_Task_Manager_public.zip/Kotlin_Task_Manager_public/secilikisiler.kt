package com.acd.taskmanager

data class SeciliKisiler(
    val AdSoyad: String
)

