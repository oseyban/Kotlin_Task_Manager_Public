package com.x.x

//********************** 2DFA doğrulama sayfası *************************************************

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthProvider

class VerificationActivity : AppCompatActivity() {

    private lateinit var editVerificationCode: EditText
    private lateinit var btnVerifyCode: Button

    private lateinit var verificationId: String // MainActivity'den alınan verificationId

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_verification)

        editVerificationCode = findViewById(R.id.editVerificationCode)
        btnVerifyCode = findViewById(R.id.btnVerifyCode)

        verificationId = intent.getStringExtra("verificationId") ?: ""

        btnVerifyCode.setOnClickListener {
            val verificationCode = editVerificationCode.text.toString()
            if (verificationCode.isNotEmpty()) {
                // Doğrulama kodunu doğrula
                verifyPhoneNumberWithCode(verificationCode)
            } else {
                Toast.makeText(this, "Lütfen doğrulama kodunu girin", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // *****************telefon ile gelen kodu doğrulama fonksiyoru********************************
    private fun verifyPhoneNumberWithCode(verificationCode: String) {
        val credential = PhoneAuthProvider.getCredential(verificationId, verificationCode)

        // Doğrulama kodunu Firebase'e gönder ve kullanıcıyı oturum açmaya zorla
        FirebaseAuth.getInstance().signInWithCredential(credential)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    // Giriş başarılı, MainActivityAuth sayfasına yönlendir
                    val intent = Intent(this, MainActivityAuth::class.java)
                    startActivity(intent)
                    finish()
                } else {
                    // Giriş işlemi başarısız
                    Toast.makeText(baseContext, "Giriş başarısız", Toast.LENGTH_SHORT).show()
                }
            }
    }
}
