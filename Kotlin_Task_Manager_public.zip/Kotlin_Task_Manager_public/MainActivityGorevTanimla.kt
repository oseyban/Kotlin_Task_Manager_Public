package com.acd.taskmanager

//********************* görev tanımlama sayfası ***************************************************
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.acd.taskanager.Gorev
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivityGorevTanimla : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.gorev_tanimla)

        val butonKaydet: Button = findViewById(R.id.butonKaydet)
        val butonGeridon: Button = findViewById(R.id.butonGeridon)
        val editGorevAdi: EditText = findViewById(R.id.editGorevAdi)
        val oncelik: Spinner = findViewById(R.id.spinnerOncelik)
        val editGorevTarihi: EditText = findViewById(R.id.editGorevTarihi)
        val gorevdurumu: Spinner = findViewById(R.id.spinnerGorevDurumu)
        val gorevaciklama: EditText = findViewById(R.id.editGorevAciklama)
        editGorevAdi.setPadding(10,0,0,0)
        editGorevTarihi.setPadding(10,0,0,0)
        gorevaciklama.setPadding(10,10,10,10)

        auth = FirebaseAuth.getInstance()

        butonKaydet.setOnClickListener {
            // Formdaki bilgileri al
            val gorevAdi = editGorevAdi.text.toString()
            val oncelikStr: String = oncelik.selectedItem.toString()
            val gorevDurumuStr: String = gorevdurumu.selectedItem.toString()
            val gorevaciklamasi = gorevaciklama.text.toString()
            val tarih = editGorevTarihi.text.toString()

            // Bilgileri kontrol et
            if (gorevAdi.isNotEmpty() && oncelikStr.isNotEmpty() && gorevDurumuStr.isNotEmpty()
            ) {
                // Bilgileri Firestore'a ekle

                val gorev =
                    Gorev(gorevAdi, oncelikStr, tarih, gorevDurumuStr, gorevaciklamasi)
                ekleFirestore(gorev,gorevAdi)
            } else {
                // Hata durumunda kullanıcıya bilgi ver
                Toast.makeText(
                    this,
                    "Hatalı giriş! Bilgilerinizi kontrol ediniz",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        butonGeridon.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            val intent = Intent(this, MainActivityAuth::class.java)
            startActivity(intent)
            finish()
        }
    }

    // ******************** Firestore veritabanına ekleme fonksiyonu*******************************
    private fun ekleFirestore(gorev: Gorev,gorevAdi:String) {
        val gorevBilgileri = mapOf(
            "gorevAdi" to gorev.gorevAdi,
            "oncelik" to gorev.oncelik,
            "tarih" to gorev.tarih,
            "durumu" to gorev.durumu,
            "aciklama" to gorev.aciklama
        )

        db.collection("gorevler").document(gorevAdi)
            .set(gorevBilgileri)
            .addOnSuccessListener {
                // Ekleme başarılı oldu
                Toast.makeText(this, "Başarıyla kaydedildi!", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
                // Ekleme başarısız oldu
                Toast.makeText(this, "Hata: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

}
