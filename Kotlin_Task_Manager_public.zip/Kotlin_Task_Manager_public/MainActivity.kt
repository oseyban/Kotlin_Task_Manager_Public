package com.acd.taskmanager

// ***************************** İlk giriş sayfası ************************************************

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore
    private lateinit var editEmail: EditText
    private lateinit var editPassword: EditText
    private lateinit var btnLogin: Button
    private lateinit var btnSignUp: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()

        editEmail = findViewById(R.id.editEmail)
        editPassword = findViewById(R.id.editPassword)
        btnLogin = findViewById(R.id.btnLogin)
        btnSignUp = findViewById(R.id.btnSignUp)
        editEmail.setPadding(20,0,0,0)

        // giriş butonuna tıklanınca
        btnLogin.setOnClickListener {
            val email = editEmail.text.toString()
            val password = editPassword.text.toString()

            if (email.isNotEmpty() && password.isNotEmpty()) {
                // Kullanıcı giriş yapmayı deniyor
                signIn(email, password)
            } else {
                Toast.makeText(this, "Lütfen email ve şifreyi girin", Toast.LENGTH_SHORT).show()
            }
        }

        // üye ol butonuna tıklanınca
        btnSignUp.setOnClickListener {
            val intent = Intent(this, MainActivitySignIn::class.java)
            startActivity(intent)
        }
    }
   //************************  üye ol fonksiyonu  ***********************************
    private fun signIn(email: String, password: String) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Giriş başarılı, Firestore'dan telefon numarasını al
                    val user = auth.currentUser
                    if (user != null) {
                        val userEmail = user.email // Kullanıcının e-posta adresini al
                        if (!userEmail.isNullOrBlank()) {
                            checkPhoneNumberInFirestore(userEmail)
                        } else {
                            Toast.makeText(this, "Kullanıcının e-posta adresi yok", Toast.LENGTH_SHORT).show()
                        }
                    }
                } else {
                    // Giriş başarısız
                    Toast.makeText(this, "Giriş başarısız", Toast.LENGTH_SHORT).show()
                }
            }
    }

    // ************************  2DFA güvenlik kontrolü  *****************************************
    private fun checkPhoneNumberInFirestore(userEmail: String) {
        val usersCollection = firestore.collection("kisiler")

        usersCollection
            .whereEqualTo("email", userEmail) // "email" alanı ile eşleşen dokümanları getir
            .get()
            .addOnSuccessListener { querySnapshot ->
                if (!querySnapshot.isEmpty) {
                    // Kullanıcı kaydı bulundu, telefon numarasını al
                    val document = querySnapshot.documents[0]
                    val phoneNumber = document.getString("telefon")
                    if (!phoneNumber.isNullOrBlank()) {
                        // Telefon numarasını aldık, şimdi doğrulama kodunu gönder
                        sendVerificationCode(phoneNumber)
                    } else {
                        Toast.makeText(baseContext, "Kullanıcının telefon numarası yok", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(baseContext, "Kullanıcı kaydı bulunamadı", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(baseContext, "Firestore'dan kullanıcı bilgileri alınamadı: $e", Toast.LENGTH_SHORT).show()
            }
    }

    // ********************* doğrulama kodunu telefona gönderme fonksiyonu *************************
    private fun sendVerificationCode(phoneNumber: String){

        val options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(phoneNumber)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(this)
            .setCallbacks(object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                    // Otomatik doğrulama tamamlandığında
                    signInWithPhoneAuthCredential(credential)
                }

                override fun onVerificationFailed(p0: FirebaseException) {
                    TODO("Not yet implemented")
                }

                fun onVerificationFailed(e: Exception) {
                    // Doğrulama başarısız olduğunda
                    Toast.makeText(baseContext, "Doğrulama başarısız", Toast.LENGTH_SHORT).show()
                }

                override fun onCodeSent(
                    verificationId: String,
                    token: PhoneAuthProvider.ForceResendingToken
                ) {
                    // Doğrulama kodu gönderildiğinde
                    // Kullanıcının bu kodu uygulamada girmesi gerekir
                    val intent = Intent(this@MainActivity, VerificationActivity::class.java)
                    intent.putExtra("verificationId", verificationId)
                    startActivity(intent)
                }
            })
            .build()

        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    //******************* telefon ile sign in işlemi********************************************
    private fun signInWithPhoneAuthCredential(credential: PhoneAuthCredential) {
        auth.signInWithCredential(credential)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    // Giriş başarılı, MainActivityAuth sayfasına yönlendir
                    val intent = Intent(this, MainActivityAuth::class.java)
                    startActivity(intent)
                    finish()
                } else {
                    // Giriş işlemi başarısız
                    Toast.makeText(this, "Giriş başarısız", Toast.LENGTH_SHORT).show()
                }
            }
    }
}
