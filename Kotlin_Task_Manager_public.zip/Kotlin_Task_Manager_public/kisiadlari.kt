package com.x.x

data class kisiAdlari(
    val AdSoyad: String,
)

