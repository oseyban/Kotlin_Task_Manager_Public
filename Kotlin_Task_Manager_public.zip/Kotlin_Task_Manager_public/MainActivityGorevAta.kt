package com.x.x

//**************************** Görev Atama Sayfası *************************************************

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.acd.taskanager.Gorev01
import com.google.android.gms.tasks.Tasks
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.*
import kotlinx.coroutines.tasks.await
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException

class MainActivityGorevAta : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.gorev_ata)

        val butonOnayla: Button = findViewById(R.id.butonOnayla)
        val butonGeridon: Button = findViewById(R.id.butonGeridon)
        val spinnerGorevAdi: Spinner = findViewById(R.id.spinnerGorevSec)
        val listView: ListView = findViewById(R.id.listViewKisiAtama)

        val kisiAdlari: MutableList<String> = mutableListOf("Görev Seçiniz")
        val listAdapter = ArrayAdapter(this, R.layout.list_item_kisi, R.id.textAdSoyad, kisiAdlari)
        listView.adapter = listAdapter

        val isimListesi = mutableListOf<String>()
        var tokenListesi: MutableList<String> = mutableListOf()


        for (i in 0 until listView.adapter.count) {
            val isim = listView.getItemAtPosition(i).toString()
            isimListesi.add(isim)
        }

        // cep telefonuna gönderilecek FCM mesajı için başlık ve gövde metni
        val baslik = "Task Manager Bildirimi"
        val mesaj = "Yeni bir görevlendirmeniz var. Lütfen görevlerinizi kontrol ediniz..."

        // ******** açılır listedeki görev adını firebase veritabanından al ************************
        getGorevAdlariFromFirestore(spinnerGorevAdi)

        // ******************* listedeki seçili kişileri veritabanından al************************
        getKisiAdlariFromFirestore(kisiAdlari, listAdapter)

        butonOnayla.setOnClickListener {
            CoroutineScope(Dispatchers.Main).launch {
                gorevlereKisiAta(spinnerGorevAdi, listView)
                kisilereGorevAta(spinnerGorevAdi, listView)

                // veritabanında gecikmeli veri işlemleri için CoroutineScope kullanıyoruz
                CoroutineScope(Dispatchers.Main).launch {
                    tokenGetir2(listView) { tokenListesi ->
                    Log.d("token Listesi-62", tokenListesi.toString())
                    // cihaz bilgisi alınan cihaza mesaj gönder
                    sendFCMMessageToDevice(tokenListesi, baslik, mesaj)
                    }
                }

            }

        }

        butonGeridon.setOnClickListener {
            val intent = Intent(this, MainActivityAuth::class.java)
            startActivity(intent)
            finish()
        }
    }

    // ******************* açılır listedeki görev adını veritabanından çekme fonksiyonu ************
    private fun getGorevAdlariFromFirestore(spinnerGorevAdi: Spinner) {
        val gorevAdlari: MutableList<String> = mutableListOf()

        db.collection("gorevler")
            .get()
            .addOnSuccessListener { result ->
                for (document in result) {
                    val gorevAdi = document.getString("gorevAdi")
                    gorevAdi?.let {
                        gorevAdlari.add(it)
                    }
                }

                val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, gorevAdlari)
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                spinnerGorevAdi.adapter = adapter
                spinnerGorevAdi.prompt = resources.getString(R.string.select_gorev)
                adapter.notifyDataSetChanged()
            }
            .addOnFailureListener { exception ->
                Log.e(TAG, "Veri alma hatası-93: ${exception.message}", exception)
            }
    }

    //**************** listede seçili kişi adlarını veritabanından çekme fonksiyonu*****************
    private fun getKisiAdlariFromFirestore(
        kisiAdlari: MutableList<String>,
        listAdapter: ArrayAdapter<String>
    ) {
        db.collection("kisiler")
            .get()
            .addOnSuccessListener { result ->
                for (document in result) {
                    val kisiAdi = document.getString("adSoyad")
                    kisiAdi?.let {
                        kisiAdlari.add(it)
                    }
                }
                listAdapter.notifyDataSetChanged()
            }
            .addOnFailureListener { exception ->
                Log.e(TAG, "kişi isimleri alma hatası-113: ${exception.message}", exception)
            }
    }

    companion object {
        const val TAG = "MainActivityGorevAta"
    }

    //*************************** Görevlere Kişi Ata ***************************************************
    private suspend fun gorevlereKisiAta(
        spinnerGorevAdi: Spinner,
        listView: ListView
    ) {
        withContext(Dispatchers.IO) {
            val seciliKisiler: MutableList<String> = mutableListOf()

            for (i in 0 until listView.count) {
                val view = listView.getChildAt(i)
                val checkBox: CheckBox = view.findViewById(R.id.checkBox)

                if (checkBox.isChecked) {
                    val textView: TextView = view.findViewById(R.id.textAdSoyad)
                    val kisiAdi = textView.text.toString()
                    seciliKisiler.add(kisiAdi)
                }
            }

            val gorevAdi1 = spinnerGorevAdi.selectedItem.toString()

            val batch = db.batch()

            try {
                val existingDocuments = db.collection("gorevler").document(gorevAdi1)
                    .collection("atananlar").get().await()

                for (document in existingDocuments) {
                    val documentRef = db.collection("gorevler").document(gorevAdi1)
                        .collection("atananlar").document(document.id)
                    batch.delete(documentRef)
                }

                batch.commit().await()

                for (kisiAdi in seciliKisiler) {
                    val atananlarRef = db.collection("gorevler").document(gorevAdi1)
                        .collection("atananlar").document(kisiAdi)

                    val gorevBilgileri = mapOf(
                        "gorevAdi" to gorevAdi1,
                        "tarih" to "",
                        "oncelik" to "",
                        "durumu" to "",
                        "aciklama" to ""
                    )

                    atananlarRef.set(gorevBilgileri)
                        .addOnSuccessListener {
                            Log.d(TAG, "Yeni görev eklendi-170: $gorevAdi1 - $kisiAdi")
                        }
                        .addOnFailureListener { exception ->
                            Log.e(
                                TAG,
                                "Yeni görev ekleme hatası-175: ${exception.message}",
                                exception
                            )
                        }
                }

                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        this@MainActivityGorevAta,
                        "Görev tamamlandı",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Yazma işlemi esnasında hata oluştu-189: ${e.message}", e)
            }
        }
    }

    //*************************** Kişilere Görev Atama Fonksiyonu ************************************
    private suspend fun kisilereGorevAta(
        spinnerGorevAdi: Spinner,
        seciliKisi: ListView
    ) {
        val seciliKisiler: MutableList<String> = mutableListOf()

        for (i in 0 until seciliKisi.count) {
            val view = seciliKisi.getChildAt(i)
            val checkBox: CheckBox = view.findViewById(R.id.checkBox)

            if (!checkBox.isChecked) {
                val textView: TextView = view.findViewById(R.id.textAdSoyad)
                val kisiAdi = textView.text.toString()
                val gorevAdi = spinnerGorevAdi.selectedItem.toString()

                kisiGorevleriniSil(kisiAdi, gorevAdi)
            }
        }

        CoroutineScope(Dispatchers.IO).launch {
            for (i in 0 until seciliKisi.count) {
                val view = seciliKisi.getChildAt(i)
                val checkBox: CheckBox = view.findViewById(R.id.checkBox)

                if (checkBox.isChecked) {
                    val textView: TextView = view.findViewById(R.id.textAdSoyad)
                    val kisiAdi = textView.text.toString()
                    seciliKisiler.add(kisiAdi)
                }
            }

            CoroutineScope(Dispatchers.IO).launch {
                for (kisiAdi in seciliKisiler) {
                    val gorevAdi = spinnerGorevAdi.selectedItem.toString()
                    var gorevAciklama = ""
                    var tarih = ""
                    var durumu = ""
                    var oncelik = ""

                    try {
                        val documents = db.collection("gorevler")
                            .whereEqualTo("gorevAdi", gorevAdi)
                            .get()
                            .await()

                        if (!documents.isEmpty) {
                            for (document in documents) {
                                val gorevBilgisi = document.toObject(Gorev01::class.java)

                                gorevAciklama = gorevBilgisi.gorevAciklama.toString()
                                durumu = gorevBilgisi.durumu.toString()
                                oncelik = gorevBilgisi.oncelik.toString()
                                tarih = gorevBilgisi.tarih.toString()
                            }
                        } else {
                            Log.d(TAG, "Görev Bulunamadı.-250")
                        }

                        val atananGorevlerRef = db.collection("kisiler").document(kisiAdi)
                            .collection("atananGorevler").document(gorevAdi)

                        val gorevBilgileri = mapOf(
                            "gorevAdi" to gorevAdi,
                            "tarih" to tarih,
                            "oncelik" to oncelik,
                            "durumu" to durumu,
                            "aciklama" to gorevAciklama
                        )

                        atananGorevlerRef.set(gorevBilgileri)
                            .addOnSuccessListener {
                                Log.d(TAG, "Görev Atama işlemi başarılı-266: $gorevAdi - $kisiAdi")
                            }
                            .addOnFailureListener { exception ->
                                Log.e(
                                    TAG,
                                    "Görev atama hatası-269: ${exception.message}",
                                    exception
                                )
                            }
                    } catch (e: Exception) {
                        Log.e(TAG, "Görev bilgisi alınamadı-272: ${e.message}", e)
                    }
                }

                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        this@MainActivityGorevAta,
                        "Görev atama işlemi tamamlandı",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    //*************************** Kişi Görevlerini Silme fonksiyonu**********************************
    private suspend fun kisiGorevleriniSil(
        kisiAdi: String,
        gorevAdi: String
    ) {
        try {
            val atananGorevlerCollection = db.collection("kisiler").document(kisiAdi)
                .collection("atananGorevler")

            val querySnapshot = atananGorevlerCollection
                .whereEqualTo("gorevAdi", gorevAdi)
                .get().await()

            val batch = db.batch()

            for (document in querySnapshot.documents) {
                val documentRef = atananGorevlerCollection.document(document.id)
                batch.delete(documentRef)
            }
            batch.commit().await()

        } catch (e: Exception) {
            Log.e(TAG, "Silme işlemi esnasında hata oluştu-309: ${e.message}", e)
        }
    }


    //******************************* FCM Mesajı Gönderme fonksiyonu********************************
    private fun sendFCMMessageToDevice(
        deviceIDList: List<String>,
        messageTitle: String,
        messageBody: String
    ) {
        // **************** Firebase Cloud Messaging API cihaz token'ı alma kodu  ******************
        val sharedPreferences = getSharedPreferences("MySharedPreferences", Context.MODE_PRIVATE)
        Log.d("FCM", "sendFCM ye  girildi-355")

        // DeviceIDList üzerinde forEach döngüsü ile işlem yapma
        deviceIDList.forEach { deviceID ->
            // Her bir cihaz için FCM token'ını al
            val deviceToken = sharedPreferences.getString("FCM_TOKEN", "")
            Log.d("FCM", "Mesaj gönderme aşaması.-360$deviceToken")

            // FCM mesajını oluştur
            val jsonBody = JSONObject()
            jsonBody.put("to", deviceID)
            jsonBody.put("priority", "high")

            // Bildirim başlığı ve içeriğini "notification" alanına ekle
            val notification = JSONObject()
            notification.put("title", messageTitle)
            notification.put("body", messageBody)

            jsonBody.put("notification", notification)

            val requestBody =
                jsonBody.toString().toRequestBody("application/json".toMediaTypeOrNull())

            // FCM mesajını gönder  *** serverKey : Firebase den alınacak
            val serverKey =
                "AAAAMNflo_I:APA91bH8xB1UrBhWITnTuywHiEexYHO2Y3B6dDfNQKc8zRUZrc26BzYm4NG5JddGkPyZlEu8yjjXRmJSTMKFMa2S_rVuVz8kYv6yv3k1Mg7W6-0bgzQhBxYd8EsAaiG6kEyUUPSwjDYn"
            val request = Request.Builder()
                .url("https://fcm.googleapis.com/fcm/send")
                .post(requestBody)
                .addHeader("Content-Type", "application/json")
                .addHeader("Authorization", "key=$serverKey")
                .build()

            val client = OkHttpClient()
            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    Log.e("FCM", "FCM mesajı gönderme hatası-387: ${e.message}")
                }

                override fun onResponse(call: Call, response: Response) {
                    Log.d("FCM", "FCM mesajı başarıyla gönderildi.-391")
                }
            })
        }
    }

//*****************************Token Getir fonksiyonu**************************************************************
// listedeki ismi işaretli kişilerin veritabanındaki token bilgilerini bulup getirir
fun tokenGetir2(listView: ListView, onComplete: (List<String>) -> Unit) {
    val seciliKisiler: MutableList<String> = mutableListOf()
    val tokenListesi: MutableList<String> = mutableListOf()

    for (i in 0 until listView.count) {
        val view = listView.getChildAt(i)
        val checkBox: CheckBox = view.findViewById(R.id.checkBox)

        if (checkBox.isChecked) {
            val textView: TextView = view.findViewById(R.id.textAdSoyad)
            val kisiAdi = textView.text.toString()
            seciliKisiler.add(kisiAdi)
        }
    }

    try {
        val tasks = seciliKisiler.map { kisiAdi ->
            db.collection("kisiler")
                .whereEqualTo("adSoyad", kisiAdi)
                .get()
                .addOnSuccessListener { documents ->
                    for (document in documents) {
                        val token = document.getString("token")
                        token?.let {
                            tokenListesi.add(it)
                            Log.d("TOKEN-398", it)
                        }
                    }
                }
                .addOnFailureListener { exception ->
                    Log.w("TAG", "Token alma hatası: ", exception)
                }
        }

        // Tüm görevlerin tamamlanmasını bekle
        Tasks.whenAllComplete(tasks).addOnCompleteListener {
            // Token listesi alındıktan sonra alınan token ı token listesine ekle
            Log.d("TokenGetir2", tokenListesi.toList().toString())
            onComplete(tokenListesi)
        }

    } catch (e: Exception) {
        Log.e("TAG", "Exception: $e")
    }
}


}