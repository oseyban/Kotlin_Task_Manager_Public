package com.acd.taskmanager

// **************************** üyelik oluşturma fonksiyonu **************************************
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.acd.taskanager.Kisi
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessaging

@Suppress("DEPRECATION")
class MainActivitySignIn : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_signin)

        val butonKaydet: Button = findViewById(R.id.butonKaydet)
        val butonGeridon: Button = findViewById(R.id.butonGeridon)
        val editAdSoyad: EditText = findViewById(R.id.editAdSoyad)
        val editEmail: EditText = findViewById(R.id.editEmail)
        val editPassword: EditText = findViewById(R.id.editPassword)
        val editPasswordR: EditText = findViewById(R.id.editPasswordR)
        val editTelefon: EditText = findViewById(R.id.editTelefon)
        val editPozisyon: EditText = findViewById(R.id.editPozisyon)
        editAdSoyad.setPadding(10,0,0,0)
        editEmail.setPadding(10,0,0,0)
        editPassword.setPadding(10,0,0,0)
        editPozisyon.setPadding(10,0,0,0)
        editTelefon.setPadding(10,0,0,0)
        editPasswordR.setPadding(10,0,0,0)

        auth = FirebaseAuth.getInstance()

        butonKaydet.setOnClickListener {
            // Formdaki bilgileri al
            val adSoyad = editAdSoyad.text.toString()
            val email = editEmail.text.toString()
            val password = editPassword.text.toString()
            val passwordR = editPasswordR.text.toString()
            val telefon = editTelefon.text.toString()
            val pozisyon = editPozisyon.text.toString()

            // Mesaj göndermek için mobil cihazın token bilgisini alır
            FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val token = task.result
                    if (adSoyad.isNotEmpty() && email.isNotEmpty() && password.isNotEmpty() &&
                        password == passwordR && telefon.isNotEmpty() && pozisyon.isNotEmpty()
                    ) {
                        // E-postanın Firebase veritabanında zaten kayıtlı olup olmadığını kontrol et
                        kontrolEtVeKaydet(email, password, adSoyad, telefon, pozisyon, token)
                    } else {
                        // Hata durumunda kullanıcıya bilgi ver
                        Toast.makeText(
                            this,
                            "Hatalı giriş! Bilgilerinizi kontrol ediniz",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    // Token alınamazsa uyarı ver
                    Toast.makeText(this, "Token alınamadı", Toast.LENGTH_SHORT).show()
                }
            }
        }

        butonGeridon.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    //************************ girilen e-posta adresi ile daha önce kayıt olunup-olunmadığını ******
    // ************************ kontrol eder ve kayıt işlemi yapar *********************************
    private fun kontrolEtVeKaydet(
        email: String,
        password: String,
        adSoyad: String,
        telefon: String,
        pozisyon: String,
        token: String
    ) {
        // E-postanın Firebase veritabanında zaten kayıtlı olup olmadığını kontrol et
        auth.fetchSignInMethodsForEmail(email)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val signInMethods = task.result?.signInMethods
                    if (signInMethods.isNullOrEmpty()) {
                        // E-posta zaten kayıtlı değil, kaydetme işlemine devam et
                        val kisi = Kisi(adSoyad, email, telefon, pozisyon, token)
                        ekleFirestore(kisi)
                        ekleFirestoreAuth(email, password)
                    } else {
                        // E-posta zaten kayıtlı, kullanıcıya uyarı ver
                        Toast.makeText(
                            this,
                            "Bu e-posta adresi zaten kayıtlı!",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    // Firebase sorgusu başarısız oldu uyarı ver
                    Toast.makeText(
                        this,
                        "Firebase Hata: ${task.exception?.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
    }

    // ************* form bilgilerini veritabanına kaydetme fonksiyonu **********************************
    private fun ekleFirestore(kisi: Kisi) {
        val kisiadi = kisi.adSoyad
        // Firestore veritabanına ekleme işlemi
        db.collection("kisiler")
            .document(kisiadi)
            .set(kisi)
            .addOnSuccessListener {
                // Ekleme başarılı oldu
                Toast.makeText(this, "Başarıyla kaydedildi!", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
                // Ekleme başarısız oldu
                Toast.makeText(this, "Hata: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    // ************* giriş bilgilerini Autentication için kaydetme fonksiyonu **********************
    private fun ekleFirestoreAuth(email: String, password: String) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Kayıt başarılıysa
                    Toast.makeText(this, "Üyelik işlemi başarılı", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    finish()
                } else {
                    // Kayıt başarısızsa
                    val errorMessage = task.exception?.message
                    // Kullanıcıya hata mesajı gönder
                    Toast.makeText(this, "Auth Hata: $errorMessage", Toast.LENGTH_SHORT).show()
                }
            }
    }
}
