package com.os.kotlin_harita

// FCM Messaging API kodları

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.acd.taskmanager.R
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class MyFirebaseMessagingService : FirebaseMessagingService() {
    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.d("FCM", "From: ${remoteMessage.from}")

        FirebaseMessaging.getInstance().token.addOnCompleteListener(OnCompleteListener { task ->
            if (!task.isSuccessful) {
                Log.w(ContentValues.TAG, "Fetching FCM registration token failed", task.exception)
                return@OnCompleteListener
            }

            // Get new FCM registration token
            val token = task.result

            // Log and toast
            val msg = getString(R.string.msg_token_fmt, token)
            Log.d(ContentValues.TAG, msg)
            //Toast.makeText(baseContext, msg, Toast.LENGTH_LONG).show()
        })
        // Gelen mesajın içeriğine ulaşma
        if (remoteMessage.data.isNotEmpty()) {
            Log.d("FCM", "Message data payload: ${remoteMessage.data}")
            // Burada gelen mesaj verileri üzerinde istediğiniz işlemleri yapabilirsiniz
        }

        // Gelen bildirimin içeriğine ulaşma
        remoteMessage.notification?.let {
            Log.d("FCM", "Message Notification Body: ${it.body}")

            // Bildirim başlığı ve içeriği
            val title = it.title ?: "Bildirim"
            val body = it.body ?: ""

            // Bildirim oluşturulması için NotificationManager
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            // Android 8.0 (Oreo) ve sonraki sürümler için bir bildirim kanalı oluşturun
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel("default", "Default Channel", NotificationManager.IMPORTANCE_DEFAULT)
                notificationManager.createNotificationChannel(channel)
            }

            // Bildirim oluştur
            val notificationBuilder = NotificationCompat.Builder(this, "default")
                .setSmallIcon(R.drawable.icon) // Bildirim simgesi (drawable olarak eklediğiniz bir ikon)
                .setContentTitle(title)
                .setContentText(body)
                .setAutoCancel(true) // Kullanıcı bildirimi tıkladığında bildirimi otomatik olarak kapat
            // İsteğe bağlı: Bildirim tıklanınca açılacak bir aktivite belirleme
            // .setContentIntent(pendingIntent)

            // Bildirimi göster
            notificationManager.notify(0, notificationBuilder.build())
        }
    }
    override fun onNewToken(token: String) {
        Log.d(ContentValues.TAG, "Refreshed token: $token")

        // If you want to send messages to this application instance or
        // manage this apps subscriptions on the server side, send the
        // FCM registration token to your app server.
       // sendRegistrationToServer(token)
    }
}



