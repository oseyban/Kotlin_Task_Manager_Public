package com.x.x

data class Bildirim(
    val baslik: String,
    val tarih: String,
    val durumu: String,
    val aciklama: String
)


